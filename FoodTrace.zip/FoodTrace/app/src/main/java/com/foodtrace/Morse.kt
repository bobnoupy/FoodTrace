package com.foodtrace

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import kotlinx.coroutines.delay

object Morse {

    val TABLE = mapOf(
        'A' to ".-", 'B' to "-...", 'C' to "-.-.", 'D' to "-..", 'E' to ".",
        'F' to "..-.", 'G' to "--.", 'H' to "....", 'I' to "..", 'J' to ".---",
        'K' to "-.-", 'L' to ".-..", 'M' to "--", 'N' to "-.", 'O' to "---",
        'P' to ".--.", 'Q' to "--.-", 'R' to ".-.", 'S' to "...", 'T' to "-",
        'U' to "..-", 'V' to "...-", 'W' to ".--", 'X' to "-..-", 'Y' to "-.--",
        'Z' to "--..",
        '0' to "-----", '1' to ".----", '2' to "..---", '3' to "...--",
        '4' to "....-", '5' to ".....", '6' to "-....", '7' to "--...",
        '8' to "---..", '9' to "----.",
        '.' to ".-.-.-", ',' to "--..--", '?' to "..--..", '/' to "-..-.",
        '=' to "-...-", '\'' to ".----."
    )

    fun encode(text: String): String =
        text.uppercase()
            .replace("É", "E").replace("È", "E").replace("Ê", "E").replace("À", "A")
            .replace("Ç", "C").replace("Ù", "U").replace("Ô", "O").replace("Î", "I")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }
            .joinToString(" / ") { word ->
                word.mapNotNull { TABLE[it] }.joinToString(" ")
            }

    /**
     * Torche robuste : set() retourne null si OK, ou un message d'erreur lisible.
     */
    class Torch(ctx: Context) {
        private val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        private val id: String? = try {
            cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (e: Exception) {
            null
        }

        val available get() = id != null

        fun set(on: Boolean): String? {
            val i = id ?: return "Aucun flash détecté sur cet appareil"
            return try {
                cm.setTorchMode(i, on)
                null
            } catch (e: Exception) {
                "Flash refusé par le système : ${e.message ?: e.javaClass.simpleName}" +
                        " (ferme l'appli caméra si elle est ouverte)"
            }
        }
    }

    /**
     * Joue le code morse. Durées en millisecondes, AUCUNE limite.
     * Si la torche renvoie une erreur au premier allumage, on arrête et on remonte l'erreur.
     */
    suspend fun play(
        torch: Torch,
        code: String,
        ti: Long,
        ta: Long,
        gapSigne: Long,
        gapLettre: Long,
        gapMot: Long,
        onError: (String) -> Unit
    ) {
        try {
            for (c in code) {
                when (c) {
                    '.' -> {
                        torch.set(true)?.let { onError(it); return }
                        delay(ti)
                        torch.set(false)
                        delay(gapSigne)
                    }
                    '-' -> {
                        torch.set(true)?.let { onError(it); return }
                        delay(ta)
                        torch.set(false)
                        delay(gapSigne)
                    }
                    ' ' -> delay(gapLettre)
                    '/' -> delay(gapMot)
                }
            }
        } finally {
            torch.set(false)
        }
    }
}
