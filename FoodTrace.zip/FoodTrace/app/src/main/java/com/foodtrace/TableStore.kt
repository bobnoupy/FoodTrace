package com.foodtrace

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Une ligne du tableau : le nom contient toute la ligne brute du ticket. */
data class Row(
    var nom: String = "",
    var qte: String = "1",
    var dlc: String = "",
    var lot: String = ""
)

object TableStore {
    const val HEADER = "Nom;Qte;DLC;Lot"

    private fun dir(ctx: Context) = File(ctx.filesDir, "tables").apply { mkdirs() }

    private fun clean(s: String) = s.replace(";", ",").replace("\n", " ").trim()

    fun newTableFile(ctx: Context): File {
        val base = SimpleDateFormat("yyyy-MM-dd_HH'h'mm", Locale.FRANCE).format(Date())
        var f = File(dir(ctx), "$base.csv")
        var i = 2
        while (f.exists()) { f = File(dir(ctx), "${base}_$i.csv"); i++ }
        return f
    }

    fun displayName(f: File) = f.name.removeSuffix(".csv").replace("_", " ")

    fun listTables(ctx: Context): List<File> =
        dir(ctx).listFiles { file -> file.name.endsWith(".csv") }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun load(f: File): MutableList<Row> {
        if (!f.exists()) return mutableListOf()
        val lines = f.readLines()
        if (lines.isEmpty()) return mutableListOf()
        // Ancien format à 6 colonnes (Nom;Marque;Qte;Prix;DLC;Lot) : on migre
        val old = lines.first().startsWith("Nom;Marque")
        return lines.drop(1).filter { it.isNotBlank() }.map { l ->
            val p = l.split(";") + List(6) { "" }
            if (old) Row(p[0], p[2], p[4], p[5]) else Row(p[0], p[1], p[2], p[3])
        }.toMutableList()
    }

    fun save(f: File, rows: List<Row>) {
        val body = rows.joinToString("\n") { r ->
            listOf(r.nom, r.qte, r.dlc, r.lot).joinToString(";") { clean(it) }
        }
        f.writeText(HEADER + "\n" + body + (if (body.isNotEmpty()) "\n" else ""))
    }

    fun share(ctx: Context, f: File) {
        val uri = FileProvider.getUriForFile(ctx, "com.foodtrace.fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Exporter " + f.name))
    }
}
