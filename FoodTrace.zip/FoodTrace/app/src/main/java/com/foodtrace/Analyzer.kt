package com.foodtrace

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Résultat du scan d'une photo produit (pour remplir DLC + lot d'une ligne). */
data class PhotoScan(
    val lines: List<String>,   // texte OCR ligne par ligne
    val autoDlc: String,       // date détectée automatiquement ("" si rien)
    val autoLot: String,       // lot détecté automatiquement ("" si rien)
    val offNom: String,        // nom via code-barres + Open Food Facts ("" si rien)
    val offMarque: String
)

object Analyzer {

    /** Lignes de ticket à ignorer (pas des produits). */
    private val SKIP = Regex(
        "(?i)\\b(total|sous[- ]?total|tva|t\\.v\\.a|carte|cb|visa|espece|espèce|especes|espèces|" +
        "rendu|monnaie|merci|bienvenue|caisse|ticket|recu|reçu|facture|montant|paiement|payer|" +
        "client|fidelite|fidélité|carte de|siret|siren|rcs|tel|tél|www|http|@|remise|promo|" +
        "solde|reduction|réduction|avantage|cumul|points|date|heure|magasin|vendeur|hote|hôte|" +
        "article[s]?\\b|nombre|quantite|qte|euros?)\\b"
    )

    /** OCR d'un ticket de caisse -> liste de lignes produits (nom, qté, prix). */
    suspend fun scanReceipt(ctx: Context, uri: Uri): List<Row> {
        val text = ocrText(ctx, uri) ?: return emptyList()
        return parseReceipt(text)
    }

    fun parseReceipt(text: String): List<Row> {
        val rows = mutableListOf<Row>()
        for (raw in text.lines()) {
            var name = raw.trim()
            if (name.length < 3) continue
            if (SKIP.containsMatchIn(name)) continue

            var prix = ""
            var qte = "1"

            // Prix en fin de ligne : "2,99" / "2.99 €" / "12,50EUR"
            Regex("""(\d+[.,]\d{2})\s*(€|eur|EUR)?\s*$""").find(name)?.let {
                prix = it.groupValues[1].replace(',', '.')
                name = name.removeRange(it.range).trim()
            }
            // Quantité en début : "2 X PRODUIT" / "3x PRODUIT"
            Regex("""^(\d{1,2})\s*[xX*]\s+""").find(name)?.let {
                qte = it.groupValues[1]
                name = name.removeRange(it.range).trim()
            }
            // Quantité en fin : "PRODUIT x2"
            Regex("""\s[xX*]\s*(\d{1,2})$""").find(name)?.let {
                qte = it.groupValues[1]
                name = name.removeRange(it.range).trim()
            }

            // Il faut au moins 3 lettres pour que ce soit un nom de produit
            if (name.count { it.isLetter() } < 3) continue
            rows.add(Row(nom = name, qte = qte, prix = prix))
        }
        return rows
    }

    /** Scan d'une photo produit : OCR ligne par ligne + détection auto + code-barres. */
    suspend fun scanPhoto(ctx: Context, uri: Uri): PhotoScan {
        var lines = listOf<String>()
        var fullText = ""
        var nom = ""
        var marque = ""

        val img = try {
            InputImage.fromFilePath(ctx, uri)
        } catch (e: Exception) {
            return PhotoScan(emptyList(), "", "", "", "")
        }

        try {
            val res = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(img).await()
            fullText = res.text
            lines = res.textBlocks.flatMap { it.lines }.map { it.text.trim() }
                .filter { it.isNotBlank() }
        } catch (_: Exception) { }

        try {
            val codes = BarcodeScanning.getClient().process(img).await()
            val code = codes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
            if (code != null && code.length >= 8 && code.all { it.isDigit() }) {
                fetchOpenFoodFacts(code)?.let { (n, m) -> nom = n; marque = m }
            }
        } catch (_: Exception) { }

        return PhotoScan(lines, findDate(fullText) ?: "", findLot(fullText) ?: "", nom, marque)
    }

    private suspend fun ocrText(ctx: Context, uri: Uri): String? {
        return try {
            val img = InputImage.fromFilePath(ctx, uri)
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(img).await().text
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun fetchOpenFoodFacts(barcode: String): Pair<String, String>? =
        withContext(Dispatchers.IO) {
            try {
                val conn = URL("https://world.openfoodfacts.org/api/v0/product/$barcode.json")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 4000
                conn.readTimeout = 4000
                conn.setRequestProperty("User-Agent", "FoodTrace-ScoutCamp/1.0")
                val txt = conn.inputStream.bufferedReader().readText()
                conn.disconnect()
                val j = JSONObject(txt)
                if (j.optInt("status") != 1) return@withContext null
                val p = j.getJSONObject("product")
                val nom = p.optString("product_name_fr").ifBlank { p.optString("product_name") }
                val marque = p.optString("brands").substringBefore(",").trim()
                if (nom.isBlank() && marque.isBlank()) null else Pair(nom, marque)
            } catch (e: Exception) {
                null
            }
        }

    /** Cherche une date plausible dans un texte. */
    fun findDate(t: String): String? {
        val full = Regex("""\b(\d{1,2})[\s./-](\d{1,2})[\s./-](\d{2,4})\b""")
        for (m in full.findAll(t)) {
            val (dd, mm, yy) = m.destructured
            val day = dd.toIntOrNull() ?: continue
            val mon = mm.toIntOrNull() ?: continue
            var yr = yy.toIntOrNull() ?: continue
            if (yy.length == 2) yr += 2000
            if (day in 1..31 && mon in 1..12 && yr in 2020..2040)
                return "%02d/%02d/%d".format(day, mon, yr)
        }
        val my = Regex("""\b(\d{1,2})[./-](\d{4})\b""")
        for (m in my.findAll(t)) {
            val (mm, yy) = m.destructured
            val mon = mm.toIntOrNull() ?: continue
            val yr = yy.toIntOrNull() ?: continue
            if (mon in 1..12 && yr in 2020..2040) return "%02d/%d".format(mon, yr)
        }
        return null
    }

    /** Cherche un numéro de lot. */
    fun findLot(t: String): String? {
        Regex("""(?i)\bLOT\s*(?:N[o°]?)?\s*[:.\-]?\s*([A-Z0-9][A-Z0-9\-/]{2,})""")
            .find(t)?.let { return it.groupValues[1] }
        Regex("""\bL[:.\s]([0-9][A-Z0-9\-/]{3,})""")
            .find(t)?.let { return it.groupValues[1] }
        return null
    }
}
