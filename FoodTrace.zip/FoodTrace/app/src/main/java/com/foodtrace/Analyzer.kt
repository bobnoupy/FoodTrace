package com.foodtrace

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Résultat du scan d'une photo produit (pour remplir DLC + lot d'une ligne). */
data class PhotoScan(
    val lines: List<String>,
    val autoDlc: String,
    val autoLot: String,
    val offNom: String   // nom via code-barres + Open Food Facts ("" si rien)
)

object Analyzer {

    /** Lignes de ticket à ignorer (en-têtes, totaux, paiement...). */
    private val SKIP = Regex(
        "(?i)\\b(total|sous[- ]?total|tva|t\\.v\\.a|carte|cb|visa|espece|espèce|especes|espèces|" +
        "rendu|monnaie|merci|bienvenue|caisse|ticket|recu|reçu|facture|montant|paiement|payer|" +
        "client|fidelite|fidélité|siret|siren|rcs|tel|tél|www|http|@|remise|promo|" +
        "solde|reduction|réduction|avantage|cumul|points|magasin|vendeur|hote|hôte|" +
        "nombre d|htva|ttc)\\b"
    )

    /** Lignes de pesée : "1,235 kg X 3,99EURO/kg" */
    private val WEIGHT = Regex("(?i)\\bkg\\b\\s*[xX*]|EURO?\\s*/|€\\s*/")

    /** Prix (éventuellement collé) en fin de ligne : "…SOUR114 EUR A", "2, 29 EUR", "5,64 EURB" */
    private val TRAILING_PRICE =
        Regex("""[\d.,\s]*(EUR(OS?)?|€)\s*[A-Z]?\s*$""", RegexOption.IGNORE_CASE)

    /** Ligne multiplicateur : "4 X 1,41" (le prix EUR a déjà été retiré avant le test) */
    private val MULTIPLIER = Regex("""^(\d{1,3})\s*[xX*][\d\s.,]*$""")

    /** OCR d'un ticket de caisse -> lignes produits nettoyées et fusionnées. */
    suspend fun scanReceipt(ctx: Context, uri: Uri): List<Row> {
        val text = ocrText(ctx, uri) ?: return emptyList()
        return parseReceipt(text)
    }

    fun parseReceipt(text: String): List<Row> {
        val out = mutableListOf<Row>()

        for (raw in text.lines()) {
            var line = raw.trim().replace(Regex("\\s+"), " ")
            if (line.length < 2) continue
            if (WEIGHT.containsMatchIn(line)) continue

            // 1) Retire un éventuel prix en fin de ligne (même collé au nom)
            line = line.replace(TRAILING_PRICE, "").trim()

            // 2) Ligne multiplicateur "4 X 1,41" -> quantité de la ligne précédente
            MULTIPLIER.find(line)?.let {
                out.lastOrNull()?.qte = it.groupValues[1]
                line = ""
            }
            if (line.isEmpty()) continue

            // 3) S'il reste moins de 3 lettres, c'était une ligne de prix ou du bruit
            if (line.count { c -> c.isLetter() } < 3) continue

            // 4) Lignes non-produits connues
            if (SKIP.containsMatchIn(line)) continue

            out.add(Row(nom = line))
        }

        // 5) Fusionne les lignes strictement identiques en additionnant les quantités
        val merged = LinkedHashMap<String, Row>()
        for (r in out) {
            val key = r.nom.uppercase().replace(Regex("\\s+"), " ").trim()
            val existing = merged[key]
            if (existing == null) {
                merged[key] = r
            } else {
                val a = existing.qte.toIntOrNull() ?: 1
                val b = r.qte.toIntOrNull() ?: 1
                existing.qte = (a + b).toString()
            }
        }
        return merged.values.toList()
    }

    /** Scan d'une photo produit : OCR ligne par ligne + détection auto + code-barres. */
    suspend fun scanPhoto(ctx: Context, uri: Uri): PhotoScan {
        var lines = listOf<String>()
        var fullText = ""
        var nom = ""

        val img = try {
            InputImage.fromFilePath(ctx, uri)
        } catch (e: Exception) {
            return PhotoScan(emptyList(), "", "", "")
        }

        try {
            val res = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(img).await()
            fullText = res.text
            lines = res.textBlocks.flatMap { it.lines }.map { it.text.trim() }
                .filter { it.isNotBlank() }
        } catch (_: Exception) { }

        try {
            val codes = BarcodeScanning.getClient().process(img).await()
            val code = codes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
            if (code != null && code.length >= 8 && code.all { it.isDigit() }) {
                fetchOpenFoodFacts(code)?.let { nom = it }
            }
        } catch (_: Exception) { }

        return PhotoScan(lines, findDate(fullText) ?: "", findLot(fullText) ?: "", nom)
    }

    private suspend fun ocrText(ctx: Context, uri: Uri): String? {
        return try {
            val img = InputImage.fromFilePath(ctx, uri)
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(img).await().text
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun fetchOpenFoodFacts(barcode: String): String? =
        withContext(Dispatchers.IO) {
            try {
                val conn = URL("https://world.openfoodfacts.org/api/v0/product/$barcode.json")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 4000
                conn.readTimeout = 4000
                conn.setRequestProperty("User-Agent", "FoodTrace-ScoutCamp/1.0")
                val txt = conn.inputStream.bufferedReader().readText()
                conn.disconnect()
                val j = JSONObject(txt)
                if (j.optInt("status") != 1) return@withContext null
                val p = j.getJSONObject("product")
                val nom = p.optString("product_name_fr").ifBlank { p.optString("product_name") }
                val marque = p.optString("brands").substringBefore(",").trim()
                listOf(nom, marque).filter { it.isNotBlank() }.joinToString(" — ")
                    .ifBlank { null }
            } catch (e: Exception) {
                null
            }
        }

    /** Cherche une date plausible dans un texte. */
    fun findDate(t: String): String? {
        val full = Regex("""\b(\d{1,2})[\s./-](\d{1,2})[\s./-](\d{2,4})\b""")
        for (m in full.findAll(t)) {
            val (dd, mm, yy) = m.destructured
            val day = dd.toIntOrNull() ?: continue
            val mon = mm.toIntOrNull() ?: continue
            var yr = yy.toIntOrNull() ?: continue
            if (yy.length == 2) yr += 2000
            if (day in 1..31 && mon in 1..12 && yr in 2020..2040)
                return "%02d/%02d/%d".format(day, mon, yr)
        }
        val my = Regex("""\b(\d{1,2})[./-](\d{4})\b""")
        for (m in my.findAll(t)) {
            val (mm, yy) = m.destructured
            val mon = mm.toIntOrNull() ?: continue
            val yr = yy.toIntOrNull() ?: continue
            if (mon in 1..12 && yr in 2020..2040) return "%02d/%d".format(mon, yr)
        }
        return null
    }

    /** Cherche un numéro de lot. */
    fun findLot(t: String): String? {
        Regex("""(?i)\bLOT\s*(?:N[o°]?)?\s*[:.\-]?\s*([A-Z0-9][A-Z0-9\-/]{2,})""")
            .find(t)?.let { return it.groupValues[1] }
        Regex("""\bL[:.\s]([0-9][A-Z0-9\-/]{3,})""")
            .find(t)?.let { return it.groupValues[1] }
        return null
    }
}
