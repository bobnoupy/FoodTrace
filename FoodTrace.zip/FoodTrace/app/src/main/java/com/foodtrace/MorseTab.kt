package com.foodtrace

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

@Composable
fun MorseTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val torch = remember { Morse.Torch(ctx) }

    var texte by remember { mutableStateOf("SOS") }
    var ti by remember { mutableStateOf("0.15") }
    var ta by remember { mutableStateOf("0.45") }
    var gSigne by remember { mutableStateOf("0.15") }
    var gLettre by remember { mutableStateOf("0.45") }
    var gMot by remember { mutableStateOf("1.05") }
    var playing by remember { mutableStateOf(false) }
    var testOn by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }

    val code = Morse.encode(texte)

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_LONG).show()

    /** Secondes (texte libre, virgule ou point) -> millisecondes. Aucune limite haute. */
    fun ms(s: String): Long =
        ((s.replace(',', '.').toDoubleOrNull() ?: 0.0) * 1000).toLong().coerceAtLeast(1)

    Column(
        Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Émetteur Morse", style = MaterialTheme.typography.headlineSmall)
        if (!torch.available) {
            Text("⚠️ Pas de flash détecté sur cet appareil",
                color = MaterialTheme.colorScheme.error)
        }

        OutlinedTextField(
            value = texte, onValueChange = { texte = it },
            label = { Text("Message") }, modifier = Modifier.fillMaxWidth()
        )
        Text(code.ifBlank { "—" }, fontFamily = FontFamily.Monospace, fontSize = 16.sp)

        @Composable
        fun champ(label: String, value: String, onChange: (String) -> Unit) {
            OutlinedTextField(
                value = value, onValueChange = onChange,
                label = { Text(label) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
        }

        Text("Durées en secondes (décimales OK, ex : 0.15 ou 12) — aucune limite",
            style = MaterialTheme.typography.bodySmall)
        champ("Ti (point)", ti) { ti = it }
        champ("Ta (trait)", ta) { ta = it }
        champ("Espace entre signes", gSigne) { gSigne = it }
        champ("Espace entre lettres", gLettre) { gLettre = it }
        champ("Espace entre mots", gMot) { gMot = it }

        TextButton(onClick = {
            val t = ti.replace(',', '.').toDoubleOrNull() ?: 0.15
            fun fmt(x: Double) = if (x == x.toLong().toDouble()) "${x.toLong()}" else "$x"
            ta = fmt(t * 3); gSigne = fmt(t); gLettre = fmt(t * 3); gMot = fmt(t * 7)
        }) { Text("Régler auto depuis le Ti (convention 1-3-1-3-7)") }

        // Test manuel de la lampe pour diagnostiquer
        OutlinedButton(
            onClick = {
                val err = torch.set(!testOn)
                if (err != null) toast(err) else testOn = !testOn
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (testOn) "🔦 Éteindre la lampe (test)" else "🔦 Test lampe : allumer") }

        Spacer(Modifier.height(4.dp))
        if (!playing) {
            Button(
                onClick = {
                    testOn = false
                    playing = true
                    job = scope.launch {
                        Morse.play(
                            torch, code,
                            ms(ti), ms(ta), ms(gSigne), ms(gLettre), ms(gMot)
                        ) { err -> toast(err) }
                        playing = false
                    }
                },
                enabled = code.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(60.dp)
            ) { Text("▶  Émettre", fontSize = 18.sp) }
        } else {
            Button(
                onClick = { job?.cancel(); torch.set(false); playing = false },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.fillMaxWidth().height(60.dp)
            ) { Text("■  Stop", fontSize = 18.sp) }
        }
    }
}
