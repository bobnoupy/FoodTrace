package com.foodtrace

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun TraceTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var screen by remember { mutableStateOf("list") }
    var tables by remember { mutableStateOf(TableStore.listTables(ctx)) }
    var currentFile by remember { mutableStateOf<File?>(null) }
    val rows = remember { mutableStateListOf<Row>() }
    var editIndex by remember { mutableIntStateOf(-1) }
    var busy by remember { mutableStateOf(false) }

    // Brouillon de nouvelle table (photos du ticket)
    val draftRows = remember { mutableStateListOf<Row>() }
    var photoCount by remember { mutableIntStateOf(0) }

    // Plomberie photo
    var tempFile by remember { mutableStateOf<File?>(null) }
    var photoTarget by remember { mutableStateOf("receipt") } // "receipt" ou "row"
    var scan by remember { mutableStateOf<PhotoScan?>(null) }

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    fun persist() {
        currentFile?.let { TableStore.save(it, rows) }
    }

    fun openTable(f: File) {
        currentFile = f
        rows.clear()
        rows.addAll(TableStore.load(f))
        screen = "table"
    }

    fun handlePhoto(uri: Uri) {
        busy = true
        scope.launch {
            if (photoTarget == "receipt") {
                val newRows = Analyzer.scanReceipt(ctx, uri)
                draftRows.addAll(newRows)
                photoCount++
                if (newRows.isEmpty()) toast("Aucun produit détecté sur cette photo")
            } else {
                scan = Analyzer.scanPhoto(ctx, uri)
                screen = "assign"
            }
            tempFile?.delete()
            tempFile = null
            busy = false
        }
    }

    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = tempFile
        if (ok && f != null) {
            handlePhoto(FileProvider.getUriForFile(ctx, "com.foodtrace.fileprovider", f))
        } else {
            tempFile?.delete(); tempFile = null
        }
    }

    val pickImage = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) handlePhoto(uri) }

    fun launchCamera(target: String) {
        photoTarget = target
        val dir = File(ctx.cacheDir, "photos").apply { mkdirs() }
        val f = File(dir, "capture_${System.currentTimeMillis()}.jpg")
        tempFile = f
        takePicture.launch(FileProvider.getUriForFile(ctx, "com.foodtrace.fileprovider", f))
    }

    fun launchGallery(target: String) {
        photoTarget = target
        pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    when {
        busy -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Spacer(Modifier.height(16.dp))
                Text("Analyse de l'image…")
            }
        }

        screen == "capture" -> CaptureScreen(
            draftRows = draftRows,
            photoCount = photoCount,
            onCamera = { launchCamera("receipt") },
            onGallery = { launchGallery("receipt") },
            onAddEmpty = { draftRows.add(Row()) },
            onRemove = { i -> draftRows.removeAt(i) },
            onValidate = {
                val f = TableStore.newTableFile(ctx)
                TableStore.save(f, draftRows.toList())
                tables = TableStore.listTables(ctx)
                draftRows.clear(); photoCount = 0
                openTable(f)
            },
            onCancel = { draftRows.clear(); photoCount = 0; screen = "list" }
        )

        screen == "table" && currentFile != null -> TableScreen(
            title = TableStore.displayName(currentFile!!),
            rows = rows,
            onRowClick = { i -> editIndex = i; screen = "edit" },
            onAddRow = {
                rows.add(Row()); persist()
                editIndex = rows.size - 1; screen = "edit"
            },
            onSerial = {
                if (rows.isNotEmpty()) { editIndex = 0; screen = "edit" }
            },
            onExport = { persist(); TableStore.share(ctx, currentFile!!) },
            onBack = { persist(); tables = TableStore.listTables(ctx); screen = "list" }
        )

        screen == "edit" && editIndex in rows.indices -> RowEditScreen(
            index = editIndex,
            total = rows.size,
            row = rows[editIndex],
            onUpdate = { r -> rows[editIndex] = r; persist() },
            onPhoto = { launchCamera("row") },
            onPhotoGallery = { launchGallery("row") },
            onPrev = { if (editIndex > 0) { persist(); editIndex-- } },
            onNext = { if (editIndex < rows.size - 1) { persist(); editIndex++ } },
            onDelete = {
                rows.removeAt(editIndex); persist()
                screen = "table"
            },
            onDone = { persist(); screen = "table" }
        )

        screen == "assign" && scan != null && editIndex in rows.indices -> AssignScreen(
            row = rows[editIndex],
            scan = scan!!,
            onValidate = { dlc, lot ->
                val r = rows[editIndex]
                rows[editIndex] = r.copy(
                    dlc = dlc,
                    lot = lot,
                    nom = r.nom.ifBlank { scan!!.offNom },
                    marque = r.marque.ifBlank { scan!!.offMarque }
                )
                persist()
                scan = null
                screen = "edit"
            },
            onCancel = { scan = null; screen = "edit" }
        )

        else -> TablesListScreen(
            tables = tables,
            onOpen = { openTable(it) },
            onShare = { TableStore.share(ctx, it) },
            onDelete = { f ->
                f.delete()
                tables = TableStore.listTables(ctx)
            },
            onNew = { draftRows.clear(); photoCount = 0; screen = "capture" }
        )
    }
}

/* ---------- Accueil : liste des tables ---------- */

@Composable
fun TablesListScreen(
    tables: List<File>,
    onOpen: (File) -> Unit,
    onShare: (File) -> Unit,
    onDelete: (File) -> Unit,
    onNew: () -> Unit
) {
    var toDelete by remember { mutableStateOf<File?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Traçabilité", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onNew, modifier = Modifier.fillMaxWidth().height(60.dp)) {
            Text("＋ Nouvelle table (photo du ticket)", fontSize = 17.sp)
        }
        Spacer(Modifier.height(12.dp))

        if (tables.isEmpty()) {
            Text("Aucune table pour l'instant.", style = MaterialTheme.typography.bodyMedium)
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tables) { f ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(f) }) {
                    Row(
                        Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(TableStore.displayName(f),
                                style = MaterialTheme.typography.titleMedium)
                            Text("${TableStore.load(f).size} ligne(s)",
                                style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { onShare(f) }) { Text("📤") }
                        TextButton(onClick = { toDelete = f }) { Text("🗑") }
                    }
                }
            }
        }
    }

    toDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Supprimer cette table ?") },
            text = { Text(TableStore.displayName(f) + " sera définitivement supprimée.") },
            confirmButton = {
                TextButton(onClick = { onDelete(f); toDelete = null }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Annuler") } }
        )
    }
}

/* ---------- Nouvelle table : photos du ticket ---------- */

@Composable
fun CaptureScreen(
    draftRows: List<Row>,
    photoCount: Int,
    onCamera: () -> Unit,
    onGallery: () -> Unit,
    onAddEmpty: () -> Unit,
    onRemove: (Int) -> Unit,
    onValidate: () -> Unit,
    onCancel: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Nouvelle table", style = MaterialTheme.typography.headlineSmall)
        Text("Prends le ticket de caisse en photo (plusieurs photos possibles pour un long ticket), puis valide.",
            style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onCamera, modifier = Modifier.weight(1f).height(56.dp)) {
                Text("📷 Photo")
            }
            OutlinedButton(onClick = onGallery, modifier = Modifier.weight(1f).height(56.dp)) {
                Text("🖼 Galerie")
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("$photoCount photo(s) — ${draftRows.size} produit(s) détecté(s)",
            style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(4.dp))

        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            itemsIndexed(draftRows) { i, r ->
                Card {
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.nom, style = MaterialTheme.typography.bodyMedium)
                            Text("x${r.qte}" + if (r.prix.isNotBlank()) " — ${r.prix} €" else "",
                                style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { onRemove(i) }) { Text("✕") }
                    }
                }
            }
        }

        TextButton(onClick = onAddEmpty) { Text("＋ Ajouter une ligne vide") }
        Button(
            onClick = onValidate,
            enabled = draftRows.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("✔ Valider — créer la table") }
        OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Annuler") }
    }
}

/* ---------- Vue tableau ---------- */

@Composable
fun TableScreen(
    title: String,
    rows: List<Row>,
    onRowClick: (Int) -> Unit,
    onAddRow: () -> Unit,
    onSerial: () -> Unit,
    onExport: () -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onBack) { Text("← Tables") }
            OutlinedButton(onClick = onAddRow) { Text("＋ Ligne") }
            OutlinedButton(onClick = onSerial) { Text("✏️ Série") }
            OutlinedButton(onClick = onExport) { Text("📤") }
        }
        Spacer(Modifier.height(8.dp))
        Text("Touche une ligne pour la remplir (DLC + lot).",
            style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(4.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(rows) { i, r ->
                val done = r.dlc.isNotBlank() && r.lot.isNotBlank()
                Card(Modifier.fillMaxWidth().clickable { onRowClick(i) }) {
                    Column(Modifier.padding(10.dp)) {
                        Text(
                            (if (done) "✅ " else "⬜ ") + r.nom.ifBlank { "(sans nom)" } +
                                    if (r.marque.isNotBlank()) " — ${r.marque}" else "",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            "x${r.qte}" +
                                    (if (r.prix.isNotBlank()) " · ${r.prix} €" else "") +
                                    " · DLC : " + r.dlc.ifBlank { "—" } +
                                    " · Lot : " + r.lot.ifBlank { "—" },
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}

/* ---------- Édition d'une ligne ---------- */

@Composable
fun RowEditScreen(
    index: Int,
    total: Int,
    row: Row,
    onUpdate: (Row) -> Unit,
    onPhoto: () -> Unit,
    onPhotoGallery: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onDelete: () -> Unit,
    onDone: () -> Unit
) {
    // Réinitialise les champs quand on change de ligne
    key(index) {
        var nom by remember { mutableStateOf(row.nom) }
        var marque by remember { mutableStateOf(row.marque) }
        var qte by remember { mutableStateOf(row.qte) }
        var prix by remember { mutableStateOf(row.prix) }
        var dlc by remember { mutableStateOf(row.dlc) }
        var lot by remember { mutableStateOf(row.lot) }
        var showMore by remember { mutableStateOf(false) }

        fun push() = onUpdate(Row(nom, marque, qte, prix, dlc, lot))

        Column(
            Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Bandeau : ligne en cours
            Card(colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("Ligne ${index + 1} / $total",
                        style = MaterialTheme.typography.labelMedium)
                    Text(nom.ifBlank { "(sans nom)" },
                        style = MaterialTheme.typography.titleLarge)
                }
            }

            OutlinedTextField(value = dlc, onValueChange = { dlc = it; push() },
                label = { Text("Date de péremption") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = lot, onValueChange = { lot = it; push() },
                label = { Text("N° de lot") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onPhoto, modifier = Modifier.weight(1f).height(56.dp)) {
                    Text("📷 Par photo")
                }
                OutlinedButton(onClick = onPhotoGallery,
                    modifier = Modifier.weight(1f).height(56.dp)) {
                    Text("🖼 Galerie")
                }
            }

            TextButton(onClick = { showMore = !showMore }) {
                Text(if (showMore) "Masquer les autres champs"
                     else "Modifier nom / marque / qté / prix")
            }
            if (showMore) {
                OutlinedTextField(value = nom, onValueChange = { nom = it; push() },
                    label = { Text("Produit") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = marque, onValueChange = { marque = it; push() },
                    label = { Text("Marque") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = qte, onValueChange = { qte = it; push() },
                    label = { Text("Quantité") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = prix, onValueChange = { prix = it; push() },
                    label = { Text("Prix") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onPrev, enabled = index > 0,
                    modifier = Modifier.weight(1f)) { Text("← Préc.") }
                OutlinedButton(onClick = onNext, enabled = index < total - 1,
                    modifier = Modifier.weight(1f)) { Text("Suiv. →") }
            }
            Button(onClick = onDone, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                Text("✔ Retour au tableau")
            }
            TextButton(onClick = onDelete, modifier = Modifier.fillMaxWidth()) {
                Text("🗑 Supprimer cette ligne", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

/* ---------- Assignation DLC / lot depuis une photo ---------- */

@Composable
fun AssignScreen(
    row: Row,
    scan: PhotoScan,
    onValidate: (String, String) -> Unit,
    onCancel: () -> Unit
) {
    var dlc by remember { mutableStateOf(scan.autoDlc) }
    var lot by remember { mutableStateOf(scan.autoLot) }
    // Cible du prochain tap : d'abord la date, puis le lot
    var target by remember { mutableStateOf(if (scan.autoDlc.isBlank()) "dlc" else "lot") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        // Bandeau : ligne en cours
        Card(colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.fillMaxWidth().padding(12.dp)) {
                Text("Ligne en cours", style = MaterialTheme.typography.labelMedium)
                Text(row.nom.ifBlank { "(sans nom)" },
                    style = MaterialTheme.typography.titleLarge)
            }
        }
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(value = dlc, onValueChange = { dlc = it },
            label = { Text("Date de péremption") },
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = lot, onValueChange = { lot = it },
            label = { Text("N° de lot") },
            modifier = Modifier.fillMaxWidth(), singleLine = true)

        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = target == "dlc", onClick = { target = "dlc" },
                label = { Text("Prochain tap → DATE") })
            FilterChip(selected = target == "lot", onClick = { target = "lot" },
                label = { Text("→ LOT") })
        }
        Text(
            if (scan.lines.isEmpty()) "Aucun texte détecté sur la photo."
            else "Touche la ligne du texte détecté qui correspond à la " +
                    (if (target == "dlc") "DATE" else "N° de LOT") + " :",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(4.dp))

        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(scan.lines) { line ->
                Card(Modifier.fillMaxWidth().clickable {
                    if (target == "dlc") {
                        dlc = Analyzer.findDate(line) ?: line
                        target = "lot"
                    } else {
                        lot = Analyzer.findLot(line) ?: line
                    }
                }) {
                    Text(line, Modifier.padding(10.dp),
                        style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Button(onClick = { onValidate(dlc, lot) },
            modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text("✔ Valider")
        }
        OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) {
            Text("Annuler")
        }
    }
}
