# FoodTrace — Traçabilité alimentaire + Émetteur Morse

Appli Android pour remplacer le registre papier de traçabilité (camp scout, HACCP).

## Fonctionnement

**Traçabilité :**
1. Photo (caméra ou galerie) de l'étiquette du produit
2. L'appli lit automatiquement :
   - le **code-barres** → nom + marque via Open Food Facts (si réseau ; sinon champs vides)
   - le **texte** (OCR hors ligne) → date de péremption + n° de lot
3. Écran de vérification : tous les champs sont **éditables** et **facultatifs** — tape ou corrige ce qui manque, ou laisse vide
4. Quantité en un clic (+/− ou raccourcis 1, 2, 5, 10, 20)
5. Enregistrer → ligne ajoutée au CSV, **photo temporaire supprimée** (jamais dans la galerie)
6. Bouton "Exporter le CSV" → partage par mail, Drive, WhatsApp...

Le CSV utilise `;` comme séparateur (compatible Excel français).
Colonnes : `Nom;Marque;DLC;Lot;Quantite;Ajoute_le`

**Morse :**
- Champ texte → conversion automatique en morse
- 5 curseurs indépendants : ti (point), ta (trait), espace entre signes, entre lettres, entre mots
- Bouton pour recalculer automatiquement selon la convention 1-3-1-3-7 à partir du ti
- Émission avec la lampe torche, bouton Stop à tout moment

## Compilation

1. Installer [Android Studio](https://developer.android.com/studio)
2. `File > Open` → sélectionner ce dossier `FoodTrace`
3. Attendre la synchronisation Gradle (télécharge les dépendances, dont ML Kit)
4. Brancher le téléphone en USB avec le débogage USB activé, ou utiliser `Build > Build APK`
5. Cliquer sur ▶ Run

Aucune permission runtime n'est demandée : la photo passe par l'appli caméra du
téléphone, et la torche via `setTorchMode` ne nécessite pas la permission CAMERA.
Seule la permission INTERNET (automatique) est utilisée pour Open Food Facts.

## Notes

- L'OCR (ML Kit) fonctionne **entièrement hors ligne** — utile en camp sans réseau.
  Seul le nom/marque via code-barres nécessite du réseau ; sans réseau, tape-les à la main.
- La première utilisation de l'OCR peut télécharger le modèle via Google Play Services
  → lancer l'appli une fois avec du réseau avant de partir en camp.
- Astuce vitesse : cadrer serré sur la zone DLC/lot donne un meilleur OCR qu'une photo
  de tout le paquet.
