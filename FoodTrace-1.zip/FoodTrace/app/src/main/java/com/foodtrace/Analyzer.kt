package com.foodtrace

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Brouillon d'entrée : tous les champs restent éditables et peuvent être vides. */
data class Draft(
    var nom: String = "",
    var marque: String = "",
    var dlc: String = "",
    var lot: String = "",
    var texteOcr: String = ""
)

object Analyzer {

    /** Analyse complète d'une image. Ne plante jamais : si une étape échoue, le champ reste vide. */
    suspend fun analyze(ctx: Context, uri: Uri): Draft {
        val d = Draft()
        val img = try {
            InputImage.fromFilePath(ctx, uri)
        } catch (e: Exception) {
            return d
        }

        // 1) Code-barres -> Open Food Facts (nom + marque fiables)
        try {
            val codes = BarcodeScanning.getClient().process(img).await()
            val code = codes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
            if (code != null && code.length >= 8 && code.all { it.isDigit() }) {
                fetchOpenFoodFacts(code)?.let { (nom, marque) ->
                    d.nom = nom
                    d.marque = marque
                }
            }
        } catch (_: Exception) { }

        // 2) OCR -> DLC + numéro de lot
        try {
            val result = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(img).await()
            d.texteOcr = result.text
            d.dlc = findDate(result.text) ?: ""
            d.lot = findLot(result.text) ?: ""
        } catch (_: Exception) { }

        return d
    }

    /** Interroge Open Food Facts. Retourne null si hors ligne ou produit inconnu. */
    private suspend fun fetchOpenFoodFacts(barcode: String): Pair<String, String>? =
        withContext(Dispatchers.IO) {
            try {
                val conn = URL("https://world.openfoodfacts.org/api/v0/product/$barcode.json")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 4000
                conn.readTimeout = 4000
                conn.setRequestProperty("User-Agent", "FoodTrace-ScoutCamp/1.0")
                val txt = conn.inputStream.bufferedReader().readText()
                conn.disconnect()
                val j = JSONObject(txt)
                if (j.optInt("status") != 1) return@withContext null
                val p = j.getJSONObject("product")
                val nom = p.optString("product_name_fr").ifBlank { p.optString("product_name") }
                val marque = p.optString("brands").substringBefore(",").trim()
                if (nom.isBlank() && marque.isBlank()) null else Pair(nom, marque)
            } catch (e: Exception) {
                null
            }
        }

    /** Cherche une date plausible (JJ/MM/AAAA, JJ.MM.AA, ou MM/AAAA pour les DDM). */
    fun findDate(t: String): String? {
        val full = Regex("""\b(\d{1,2})[\s./-](\d{1,2})[\s./-](\d{2,4})\b""")
        for (m in full.findAll(t)) {
            val (dd, mm, yy) = m.destructured
            val day = dd.toIntOrNull() ?: continue
            val mon = mm.toIntOrNull() ?: continue
            var yr = yy.toIntOrNull() ?: continue
            if (yy.length == 2) yr += 2000
            if (day in 1..31 && mon in 1..12 && yr in 2020..2040)
                return "%02d/%02d/%d".format(day, mon, yr)
        }
        // Format MM/AAAA (fréquent sur les DDM "à consommer de préférence avant")
        val my = Regex("""\b(\d{1,2})[./-](\d{4})\b""")
        for (m in my.findAll(t)) {
            val (mm, yy) = m.destructured
            val mon = mm.toIntOrNull() ?: continue
            val yr = yy.toIntOrNull() ?: continue
            if (mon in 1..12 && yr in 2020..2040) return "%02d/%d".format(mon, yr)
        }
        return null
    }

    /** Cherche un numéro de lot : "LOT 123ABC", "Lot: X", "L 240315", "L:AB12"... */
    fun findLot(t: String): String? {
        Regex("""(?i)\bLOT\s*(?:N[o°]?)?\s*[:.\-]?\s*([A-Z0-9][A-Z0-9\-/]{2,})""")
            .find(t)?.let { return it.groupValues[1] }
        Regex("""\bL[:.\s]([0-9][A-Z0-9\-/]{3,})""")
            .find(t)?.let { return it.groupValues[1] }
        return null
    }
}
