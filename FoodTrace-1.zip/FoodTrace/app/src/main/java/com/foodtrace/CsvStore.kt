package com.foodtrace

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CsvStore {

    private const val HEADER = "Nom;Marque;DLC;Lot;Quantite;Ajoute_le"

    private fun file(ctx: Context) = File(ctx.filesDir, "tracabilite.csv")

    private fun clean(s: String) = s.replace(";", ",").replace("\n", " ").trim()

    fun append(ctx: Context, nom: String, marque: String, dlc: String, lot: String, qte: Int) {
        val f = file(ctx)
        if (!f.exists()) f.writeText(HEADER + "\n")
        val now = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date())
        f.appendText("${clean(nom)};${clean(marque)};${clean(dlc)};${clean(lot)};$qte;$now\n")
    }

    fun count(ctx: Context): Int {
        val f = file(ctx)
        if (!f.exists()) return 0
        return (f.readLines().size - 1).coerceAtLeast(0)
    }

    fun reset(ctx: Context) {
        file(ctx).delete()
    }

    fun share(ctx: Context) {
        val f = file(ctx)
        if (!f.exists()) f.writeText(HEADER + "\n")
        val uri = FileProvider.getUriForFile(ctx, "com.foodtrace.fileprovider", f)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Exporter le CSV"))
    }
}
