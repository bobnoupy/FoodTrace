package com.foodtrace

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import kotlinx.coroutines.delay

object Morse {

    val TABLE = mapOf(
        'A' to ".-", 'B' to "-...", 'C' to "-.-.", 'D' to "-..", 'E' to ".",
        'F' to "..-.", 'G' to "--.", 'H' to "....", 'I' to "..", 'J' to ".---",
        'K' to "-.-", 'L' to ".-..", 'M' to "--", 'N' to "-.", 'O' to "---",
        'P' to ".--.", 'Q' to "--.-", 'R' to ".-.", 'S' to "...", 'T' to "-",
        'U' to "..-", 'V' to "...-", 'W' to ".--", 'X' to "-..-", 'Y' to "-.--",
        'Z' to "--..",
        '0' to "-----", '1' to ".----", '2' to "..---", '3' to "...--",
        '4' to "....-", '5' to ".....", '6' to "-....", '7' to "--...",
        '8' to "---..", '9' to "----.",
        '.' to ".-.-.-", ',' to "--..--", '?' to "..--..", '/' to "-..-.",
        '=' to "-...-", '\'' to ".----."
    )

    /** "SOS AU SECOURS" -> "... --- ... / .- ..- / ..." (lettres séparées par ' ', mots par ' / ') */
    fun encode(text: String): String =
        text.uppercase()
            .replace("É", "E").replace("È", "E").replace("Ê", "E").replace("À", "A")
            .replace("Ç", "C").replace("Ù", "U").replace("Ô", "O").replace("Î", "I")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }
            .joinToString(" / ") { word ->
                word.mapNotNull { TABLE[it] }.joinToString(" ")
            }

    class Torch(ctx: Context) {
        private val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        private val id: String? = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }

        val available get() = id != null

        fun set(on: Boolean) {
            try { id?.let { cm.setTorchMode(it, on) } } catch (_: Exception) { }
        }
    }

    /**
     * Joue le code morse avec la torche. Toutes les durées en millisecondes.
     * Annulable : lancer dans une coroutine, cancel() coupe proprement (finally éteint la lampe).
     */
    suspend fun play(
        torch: Torch,
        code: String,
        ti: Long,          // durée du point
        ta: Long,          // durée du trait
        gapSigne: Long,    // silence entre points/traits d'une même lettre
        gapLettre: Long,   // silence entre lettres
        gapMot: Long,      // silence entre mots
        onProgress: (Int) -> Unit = {}
    ) {
        try {
            code.forEachIndexed { i, c ->
                onProgress(i)
                when (c) {
                    '.' -> { torch.set(true); delay(ti); torch.set(false); delay(gapSigne) }
                    '-' -> { torch.set(true); delay(ta); torch.set(false); delay(gapSigne) }
                    ' ' -> delay(gapLettre)
                    '/' -> delay(gapMot)
                }
            }
        } finally {
            torch.set(false)
        }
    }
}
