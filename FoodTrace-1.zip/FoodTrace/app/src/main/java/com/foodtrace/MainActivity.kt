package com.foodtrace

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var screen by remember { mutableStateOf("home") }
    var draft by remember { mutableStateOf<Draft?>(null) }
    var busy by remember { mutableStateOf(false) }
    var count by remember { mutableIntStateOf(CsvStore.count(ctx)) }
    var tempFile by remember { mutableStateOf<File?>(null) }

    fun cleanupTemp() {
        tempFile?.delete()
        tempFile = null
    }

    fun process(uri: Uri) {
        busy = true
        scope.launch {
            draft = Analyzer.analyze(ctx, uri)
            busy = false
            screen = "edit"
        }
    }

    // Photo via l'appli caméra du téléphone -> fichier temporaire dans le cache (pas la galerie)
    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = tempFile
        if (ok && f != null) {
            process(FileProvider.getUriForFile(ctx, "com.foodtrace.fileprovider", f))
        } else cleanupTemp()
    }

    // Image existante de la galerie (jamais supprimée, c'est la photo de l'utilisateur)
    val pickImage = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) process(uri) }

    fun launchCamera() {
        val dir = File(ctx.cacheDir, "photos").apply { mkdirs() }
        val f = File(dir, "capture_${System.currentTimeMillis()}.jpg")
        tempFile = f
        takePicture.launch(FileProvider.getUriForFile(ctx, "com.foodtrace.fileprovider", f))
    }

    when {
        busy -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Spacer(Modifier.height(16.dp))
                Text("Analyse de l'image…")
            }
        }

        screen == "edit" && draft != null -> EditScreen(
            draft = draft!!,
            onSave = { nom, marque, dlc, lot, qte ->
                CsvStore.append(ctx, nom, marque, dlc, lot, qte)
                count = CsvStore.count(ctx)
                cleanupTemp()
                draft = null
                screen = "home"
                Toast.makeText(ctx, "Enregistré ($count lignes)", Toast.LENGTH_SHORT).show()
            },
            onCancel = {
                cleanupTemp()
                draft = null
                screen = "home"
            }
        )

        screen == "morse" -> MorseScreen(onBack = { screen = "home" })

        else -> HomeScreen(
            count = count,
            onCamera = { launchCamera() },
            onGallery = { pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            onManual = { draft = Draft(); screen = "edit" },
            onMorse = { screen = "morse" },
            onExport = { CsvStore.share(ctx) },
            onReset = {
                CsvStore.reset(ctx)
                count = 0
                Toast.makeText(ctx, "Fichier réinitialisé", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
fun HomeScreen(
    count: Int,
    onCamera: () -> Unit,
    onGallery: () -> Unit,
    onManual: () -> Unit,
    onMorse: () -> Unit,
    onExport: () -> Unit,
    onReset: () -> Unit
) {
    var confirmReset by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("FoodTrace", style = MaterialTheme.typography.headlineMedium)
        Text("$count produit(s) dans le fichier", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))

        Button(onClick = onCamera, modifier = Modifier.fillMaxWidth().height(64.dp)) {
            Text("📷  Photo (caméra)", fontSize = 18.sp)
        }
        Button(onClick = onGallery, modifier = Modifier.fillMaxWidth().height(64.dp)) {
            Text("🖼  Depuis la galerie", fontSize = 18.sp)
        }
        OutlinedButton(onClick = onManual, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text("✏️  Saisie manuelle")
        }

        Spacer(Modifier.weight(1f))

        OutlinedButton(onClick = onMorse, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text("💡  Émetteur Morse")
        }
        Button(onClick = onExport, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text("📤  Exporter le CSV")
        }
        TextButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Vider le fichier", color = MaterialTheme.colorScheme.error)
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Vider le fichier ?") },
            text = { Text("Toutes les lignes seront supprimées. Pense à exporter avant !") },
            confirmButton = {
                TextButton(onClick = { onReset(); confirmReset = false }) { Text("Vider") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Annuler") }
            }
        )
    }
}

@Composable
fun EditScreen(
    draft: Draft,
    onSave: (String, String, String, String, Int) -> Unit,
    onCancel: () -> Unit
) {
    var nom by remember { mutableStateOf(draft.nom) }
    var marque by remember { mutableStateOf(draft.marque) }
    var dlc by remember { mutableStateOf(draft.dlc) }
    var lot by remember { mutableStateOf(draft.lot) }
    var qte by remember { mutableIntStateOf(1) }
    var showOcr by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Vérifier / compléter", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Tous les champs sont facultatifs : laisse vide ce qui manque.",
            style = MaterialTheme.typography.bodySmall
        )

        OutlinedTextField(value = nom, onValueChange = { nom = it },
            label = { Text("Produit") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = marque, onValueChange = { marque = it },
            label = { Text("Marque") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = dlc, onValueChange = { dlc = it },
            label = { Text("Date de péremption (DLC/DDM)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = lot, onValueChange = { lot = it },
            label = { Text("N° de lot") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

        // Quantité : gros boutons + raccourcis en un clic
        Text("Quantité", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilledTonalButton(onClick = { if (qte > 1) qte-- }) { Text("−", fontSize = 22.sp) }
            Text("$qte", fontSize = 26.sp, modifier = Modifier.widthIn(min = 40.dp))
            FilledTonalButton(onClick = { qte++ }) { Text("+", fontSize = 22.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1, 2, 5, 10, 20).forEach { n ->
                AssistChip(onClick = { qte = n }, label = { Text("$n") })
            }
        }

        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { onSave(nom, marque, dlc, lot, qte) },
            modifier = Modifier.fillMaxWidth().height(60.dp)
        ) { Text("✔  Enregistrer", fontSize = 18.sp) }
        OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Annuler") }

        if (draft.texteOcr.isNotBlank()) {
            TextButton(onClick = { showOcr = !showOcr }) {
                Text(if (showOcr) "Masquer le texte détecté" else "Voir le texte détecté (pour copier)")
            }
            if (showOcr) {
                Text(draft.texteOcr, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun MorseScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val torch = remember { Morse.Torch(ctx) }

    var texte by remember { mutableStateOf("SOS") }
    var ti by remember { mutableFloatStateOf(150f) }       // point
    var ta by remember { mutableFloatStateOf(450f) }       // trait
    var gapSigne by remember { mutableFloatStateOf(150f) }
    var gapLettre by remember { mutableFloatStateOf(450f) }
    var gapMot by remember { mutableFloatStateOf(1050f) }
    var playing by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }

    val code = Morse.encode(texte)

    Column(
        Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Émetteur Morse", style = MaterialTheme.typography.headlineSmall)
        if (!torch.available) {
            Text("⚠️ Pas de flash détecté sur cet appareil", color = MaterialTheme.colorScheme.error)
        }

        OutlinedTextField(
            value = texte, onValueChange = { texte = it },
            label = { Text("Message") }, modifier = Modifier.fillMaxWidth()
        )
        Text(code.ifBlank { "—" }, fontFamily = FontFamily.Monospace, fontSize = 16.sp)

        @Composable
        fun slider(label: String, value: Float, onChange: (Float) -> Unit, max: Float = 1500f) {
            Text("$label : ${value.toInt()} ms")
            Slider(value = value, onValueChange = onChange, valueRange = 30f..max)
        }

        slider("Ti (point)", ti, { ti = it }, 800f)
        slider("Ta (trait)", ta, { ta = it })
        slider("Espace entre signes", gapSigne, { gapSigne = it }, 800f)
        slider("Espace entre lettres", gapLettre, { gapLettre = it })
        slider("Espace entre mots", gapMot, { gapMot = it }, 3000f)

        TextButton(onClick = {
            ta = ti * 3; gapSigne = ti; gapLettre = ti * 3; gapMot = ti * 7
        }) { Text("Régler auto à partir du Ti (convention 1-3-1-3-7)") }

        Spacer(Modifier.height(8.dp))
        if (!playing) {
            Button(
                onClick = {
                    playing = true
                    job = scope.launch {
                        Morse.play(
                            torch, code,
                            ti.toLong(), ta.toLong(),
                            gapSigne.toLong(), gapLettre.toLong(), gapMot.toLong()
                        )
                        playing = false
                    }
                },
                enabled = code.isNotBlank() && torch.available,
                modifier = Modifier.fillMaxWidth().height(60.dp)
            ) { Text("▶  Émettre", fontSize = 18.sp) }
        } else {
            Button(
                onClick = { job?.cancel(); torch.set(false); playing = false },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.fillMaxWidth().height(60.dp)
            ) { Text("■  Stop", fontSize = 18.sp) }
        }

        OutlinedButton(onClick = { job?.cancel(); torch.set(false); onBack() },
            modifier = Modifier.fillMaxWidth()) { Text("Retour") }
    }
}
